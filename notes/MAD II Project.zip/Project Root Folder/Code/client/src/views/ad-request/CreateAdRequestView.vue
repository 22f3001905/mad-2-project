<script setup>
import Navbar from '@/components/Navbar.vue';
import AdRequestForm from '@/components/ad-request/AdRequestForm.vue';
</script>

<template>
    <Navbar />
    <AdRequestForm title="Create" />
</template>
